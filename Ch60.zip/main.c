#include "stdio.h"
#include "definitions.h"

int main() {

	
	printf("Main Start\n");
	printf("ourGlobal:%d\n",ourGlobal);
	printf("Main End\n");	
		
	return 0;
}














