#include "definitions.h"

int ourGlobal = 10;

