
int ourGlobal;

