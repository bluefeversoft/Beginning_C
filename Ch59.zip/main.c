#include "stdio.h"
#include "definitions.h"


int main() {

	printf("Main1 Start\n");
	
	printf("GetMyUrgentNumber:%d %s\n",GetMyUrgentNumber(),VERSION);
	
	printf("Main1 End\n");	
		
	return 0;
}














