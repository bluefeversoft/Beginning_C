#include "stdio.h"
#include "definitions.h"

int main() {

	printf("Main2 Start\n");
	printf("GetMyUrgentNumber:%d %s\n",GetMyUrgentNumber(),VERSION);
	printf("Main2 End\n");	
	return 0;
	
}














