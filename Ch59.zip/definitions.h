#define VERSION "V 1.1"

int GetMyUrgentNumber();