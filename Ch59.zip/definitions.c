#include "definitions.h"

int GetMyUrgentNumber() {
	return 10;
}

