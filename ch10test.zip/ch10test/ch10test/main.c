//
//  main.c
//  ch10test
//
//  Created by ScreenCast on 9/15/13.
//  Copyright (c) 2013 BlueFever. All rights reserved.
//

#include "stdio.h"
#include "stdlib.h"
#include "string.h"

int main() {
	
	int intArray[6];
	int indexNum = 0;
	int numEntered = 0;
	int totalEntered = 0;
	
	char input[16];
	
	for(indexNum = 0; indexNum < 6; indexNum++) {
		printf("Enter a number ->");
		fgets(input, 16, stdin);
		
		if(strncmp(input,"q",1)==0) {
			break;
		}
		
		numEntered = atoi(input);
		
		printf("You entered:%d\n\n",numEntered);
		
		intArray[indexNum] = numEntered;
		totalEntered++;
	}
	
	printf("\n\nEntry complete, total entered:%d\n",totalEntered);
	
	for(indexNum = 0; indexNum < totalEntered; indexNum++) {
		printf("intArray[%d]=%d\n",indexNum,intArray[indexNum]);
	}
	
	
	return 0;
}




