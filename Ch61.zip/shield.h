#ifndef __SHIELD_H__
#define __SHIELD_H__

#include "definitions.h"

typedef struct {
	int num;
} S_SHIELD;

void ShieldData(S_DATA data);

int GetShieldValue();

#endif