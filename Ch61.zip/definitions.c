#include "definitions.h"

int ourGlobal = 10;

void MakeUse(S_SHIELD shield); {
	
}

