#include "shield.h"

void ShieldData(S_DATA data) {
	data.num = 10;
}

int GetShieldValue() {
	return 100;
}

