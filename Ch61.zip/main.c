#include "stdio.h"
#include "definitions.h"
#include "shield.h"

int main() {

	
	printf("Main Start\n");
	printf("ourGlobal:%d\n",ourGlobal);
	printf("shieldValue:%d\n",GetShieldValue());
	printf("Main End\n");	
		
	return 0;
}














