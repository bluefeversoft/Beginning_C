#ifndef __DEFINITIONS_H__
#define __DEFINITIONS_H__

#include "shield.h"

int ourGlobal;

typedef struct {
	int num;
} S_DATA;

void MakeUse(S_SHIELD shield);

#endif


